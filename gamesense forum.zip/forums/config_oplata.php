<?php
// ID продавца в сервисе Digiseller.ru
$id_seller = 963179;

// пароль продавца
$pass_DS = "769AD89B47"; 
?>
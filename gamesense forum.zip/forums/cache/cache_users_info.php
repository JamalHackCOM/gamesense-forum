<?php

define('PUN_USERS_INFO_LOADED', 1);

$stats = array (
  'total_users' => '45',
  'last_user' => 
  array (
    'id' => '47',
    'username' => 'millionware',
    'group_id' => '4',
  ),
);

?>
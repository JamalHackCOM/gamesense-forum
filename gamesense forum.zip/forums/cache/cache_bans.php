<?php

define('PUN_BANS_LOADED', 1);

$pun_bans = array (
  0 => 
  array (
    'id' => '4',
    'username' => 'dividedbetween',
    'ip' => '192.154.198.24',
    'email' => 'divided3222@gmail.com',
    'message' => 'Shared acc / invite trading.     Nah bro I know what happened',
    'expire' => NULL,
    'ban_creator' => '2',
  ),
);

?>
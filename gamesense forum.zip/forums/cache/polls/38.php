<?php

$kol = 1;

$rez = array (
  'questions' => 
  array (
    1 => 'You like???',
  ),
  'choices' => 
  array (
    1 => 
    array (
      1 => 'yes',
      2 => 'no (im gay btw)',
    ),
  ),
  'votes' => 
  array (
    1 => 
    array (
      1 => '5',
      2 => '1',
    ),
  ),
  'type' => 
  array (
    1 => '1',
  ),
);

?>
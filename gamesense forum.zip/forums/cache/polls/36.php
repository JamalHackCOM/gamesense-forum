<?php

$kol = 1;

$rez = array (
  'questions' => 
  array (
    1 => 'do you agree?',
  ),
  'choices' => 
  array (
    1 => 
    array (
      1 => 'i agree with this feedback',
      2 => 'i agree with this feedback',
    ),
  ),
  'votes' => 
  array (
    1 => 
    array (
      1 => '2',
      2 => '1',
    ),
  ),
  'type' => 
  array (
    1 => '1',
  ),
);

?>
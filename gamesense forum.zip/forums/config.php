<?php

$db_type = 'mysqli';
$db_host = 'localhost';
$db_name = 'gamesens_forum'; // base
$db_username = 'gamesens_forumadmin'; //login bd
$db_password = 'logan1591'; //pass db
$db_prefix = '';
$p_connect = false;

$cookie_name = 'gamesbruh_cookie';
$cookie_domain = '';
$cookie_path = '/';
$cookie_secure = 0;
$cookie_seed = 'l81u7R6X4ab2eDKadsd';

define('PUN', 1);

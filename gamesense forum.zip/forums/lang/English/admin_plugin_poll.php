<?php

$lang_admin_plugin_poll = array(

'Plugin title'	=>	'Poll',
'Explanation 1'	=>	'The plugin serves for adjustment of polls at your forum.',
'Explanation 2'	=>	'You can on or off polls at this forum, adjust number of questions, variants of answers and other parameters.',
'Form title'	=>	'Options',
'Show text button'	=>	'Save changes',
'Plugin redirect'	=>	'Options updated. Redirecting …',
'Legend1'	=>	'Global options',
'Legend3'	=>	'Additional options',
'Q1' => 'To use polls at this forum.',
'Q2' => 'The maximum number of questions in one poll. <strong>It is recommended to establish once!</strong>',
'Q3' => 'The maximum number of answers in one question. <strong>It is recommended to establish once!</strong>',
'Q4' => 'Time of editing of poll (in minutes). <strong>0 - time without restrictions.</strong>',
'Q5' => 'Poll to which set it is possible to hide results of poll. <strong>Joins in poll.</strong>',
'Q6' => 'Guests see results of voting.',

);

<?php

// Language definitions used in chatbox.php
$lang_chatbox = array(

'Page_title'				=>	'ChatBox',
'Chatbox'					=>	'ChatBox',
'Posts'						=>	' ChatBox Posts',
'Sending'					=>	'Sending...',

'No Read Permission'		=>	'You do not have permission to read ChatBox.',
'No Post Permission'		=>	'You do not have permission to post in ChatBox.',
'No Message'				=>	'No messages in ChatBox.',

'Message'					=>	'Message',
'Btn Send'					=>	'Send',

'Error Title'				=>	'Error',
'Error No message'			=>	'You must enter a message.',
'Error Too long message'	=>	'Your message is too long.',

);

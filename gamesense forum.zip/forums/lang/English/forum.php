<?php

// Language definitions used in viewforum.php
$lang_forum = array(

'Post topic'	=>	'Post new topic',
'Views'			=>	'Views',
'Moved'			=>	'Moved:',
'Sticky'		=>	'★',
'Closed'		=>	'',
'Empty forum'	=>	'Forum is empty.',
'Mod controls'	=>	'Moderator controls',
'Is subscribed'	=>	'You are currently subscribed to this forum',
'Unsubscribe'	=>	'Unsubscribe',
'Poll' => 'Poll',
'Subscribe'		=>	'Subscribe to this forum'


#   ATTENTION!!!   ATTENTION!!!   ATTENTION!!!
# For Russian
# 'Poll' => 'РћРїСЂРѕСЃ',
# For French
# 'Poll' => 'Sondage',
# For Polish
# 'Poll' => 'Ankieta',
# For Dutch
# 'Poll' => 'Poll',
#   ATTENTION!!!   ATTENTION!!!   ATTENTION!!!


);
